const ReactDOM = require('react-dom');

const App = require('./__App.jsx');

ReactDOM.render(
  <App/>,
  document.getElementById('app')
);
