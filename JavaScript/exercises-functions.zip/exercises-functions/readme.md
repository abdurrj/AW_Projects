Exercises Functions
===================

0. Open terminal / command line at this folder
1. Run `npm install`
2. Run `npm start`
3. Open browser at [http://localhost:3000/webpack-dev-server/index.html](localhost:3000/webpack-dev-server/index.html)
4. The actual exercises are found at `src/exercises/X.js`

As you are solving exercises and save the file, the results will automatically update and reflect whether you have solved the exercise or not
