package no.academy.lanterna;

import com.googlecode.lanterna.terminal.Terminal;

import javax.swing.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class GameBoard extends JFrame {



    /**
     * Method to create and stack lines, creating solid blocks with specified height and width.
     * @param height is the vertical height
     * @param width is the horizontal width
     * @param xStartPos starting row
     * @param yStartPos starting column
     * @return List of Line objects
     * */
    public static List<Line> boxMaker(int height, int width, int xStartPos, int yStartPos){
        List<Line> box = new ArrayList<>();
        for (int i = 0; i < width; i++) {
            box.add(new VerticalLine(height, xStartPos+i, yStartPos));
        }
        return box;
    }

    /**
     * Static method to make the game board with outer walls and obstacles in the middle.
     * To make walls
     * @param terminal is the terminal running the game
     * @return List of Line objects
     * */
    public static List<Line> mapMaker(Terminal terminal) throws IOException {
        List<Line> lineList = new ArrayList<>();
        int terminalSizeX = terminal.getTerminalSize().getRows();
        int terminalSizeY = terminal.getTerminalSize().getColumns();

        // Walls
        Line lWall = new VerticalLine(terminalSizeY, 1, 0);
        Line lWallB = new VerticalLine(terminalSizeY, 0, 0);
        Line rWall = new VerticalLine(terminalSizeY, terminalSizeY - 1, 0);
        Line rWallB = new VerticalLine(terminalSizeY, terminalSizeY - 2, 0);
        Line upperWall = new HorizontalLine(terminalSizeY, 0, 0);
        Line lowerWall = new HorizontalLine(terminalSizeY, 0, terminalSizeX - 1);

        // Boxes
        for (int i = 9; i<terminalSizeY-13;i+=13){
            lineList.addAll(boxMaker(2, 10, i, 3));
            lineList.addAll(boxMaker(2, 10, i, 7));
            lineList.addAll(boxMaker(2, 10, i, 19));
            lineList.addAll(boxMaker(2, 10, i, 15));
            lineList.addAll(boxMaker(4, 4, i+3, 10));
        }

        // Add walls to wall list
        lineList.add(lWall);
        lineList.add(lWallB);
        lineList.add(rWall);
        lineList.add(rWallB);
        lineList.add(upperWall);
        lineList.add(lowerWall);

        return lineList;
    }

}
