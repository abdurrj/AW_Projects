package no.academy.assessmenttest2prep2;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
class EmployeeController {

    public List<EmployeeVO> employeeVOList = new ArrayList<>();

    /*
       Make a GetMapping on "/employee" where it takes in an "id" that is not required, and returns the employee with that id, else returns nothing.
     */


    /*
        Make a GetMapping on "/employees" where it returns a list of all employees.
     */


    /*
        Make a GetMapping on "/employeesNumber" where it returns the number of employees.
     */


    /*
        Make a PostMapping on "/employee" where it takes in an EmployeeVO, adds it, and returns a responseEntity with the created user and status created.
        Hint: RequestBody, ResponseEntity
     */


    /*
        Make a DeleteMapping on "/deleteAllEmployees" that deletes all employees.
     */

}
