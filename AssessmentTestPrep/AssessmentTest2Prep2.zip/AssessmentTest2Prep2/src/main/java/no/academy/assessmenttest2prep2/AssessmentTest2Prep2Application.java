package no.academy.assessmenttest2prep2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssessmentTest2Prep2Application {

    public static void main(String[] args) {
        SpringApplication.run(AssessmentTest2Prep2Application.class, args);
    }

}
