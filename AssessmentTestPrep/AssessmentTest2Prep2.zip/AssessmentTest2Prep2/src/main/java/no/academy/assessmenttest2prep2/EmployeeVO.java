package no.academy.assessmenttest2prep2;

public class EmployeeVO {

}
