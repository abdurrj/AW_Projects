package no.academy.assessmenttest2prep2;

import java.util.List;

public class Methods {

    /*
        Reverse the String
     */
    public static String reverseString(String reverseThisString) {
        return "";
    }

    /*
        Reverse list the list
     */
    public static List<String> reverseList(List<String> reverseThisString) {
        return null;
    }

    /*
        Volume of a rectangular pyramid
     */
    public static double volumeOfAPyramid(int length, int width, int height) {
        return 0;
    }

    /*
        Volume of a Sphere
     */
    public static double volumeOfASphere(int radius) {
        return 0;
    }

    /*
        Use Stream and return the values in uppercase.
        Hint: map, collect.
     */
    public static List<String> yellNames(List<String> stringList) {
        return null;
    }

    /*
        Get the total number of letters of names longer than five(5).
        Hint: filter, mapToInt, sum.
     */
    public static int getTotalNumberOfLettersOfNamesLongerThanFive(String... names) {
        return 0;
    }

    /*
        Check if number is prime number or not.
     */
    public static boolean isPrimeNumber(int numberToCheck) {
        return false;
    }

    /*
        Very hard task
        We want to make a row of bricks that is goal inches long.
        We have a number of small bricks (1 inch each) and big bricks (5 inches each).
        Return true if it is possible to make the goal by choosing from the given bricks.
     */
    public static boolean calculateIfWeCanSucceedAtBrickLaying(int small, int big, int goal) {
        return false;
    }
}
