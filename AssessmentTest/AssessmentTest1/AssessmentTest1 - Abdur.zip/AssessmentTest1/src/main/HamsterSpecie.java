public enum HamsterSpecie {
    SYRIAN, CAMPBELL, WINTER_WHITE, ROBOROVSKI
}
