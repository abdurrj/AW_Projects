package com.payment;


public interface Payment {

    void pay(int amount);
}
