package com.payment;

public enum PaymentMethods {

    CARD,
    PAYPAL,
    VIPPS

}
