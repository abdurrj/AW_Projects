INSERT INTO BOOK (TITLE, AUTHOR, PRICE) VALUES ('Spring Boot in Action', 'Craig Walls', 40);
INSERT INTO BOOK (TITLE, AUTHOR, PRICE) VALUES ('Pro Spring Boot 2', 'Felipe Gutierrez', 24);
INSERT INTO BOOK (TITLE, AUTHOR, PRICE) VALUES ('Learning Spring Boot 2.0', 'Greg L. Turnquist', 22);
INSERT INTO BOOK (TITLE, AUTHOR, PRICE) VALUES ('Cloud Native Java', 'Josh Long and Kenny Bastani', 47);
INSERT INTO BOOK (TITLE, AUTHOR, PRICE) VALUES ('Spring Boot 2 Recipes', 'Marten Deinum', 32);
INSERT INTO BOOK (TITLE, AUTHOR, PRICE) VALUES ('Mastering Spring Boot 2.0', 'Dinesh Rajput', 31);
INSERT INTO BOOK (TITLE, AUTHOR, PRICE) VALUES ('Spring Boot 2.0 Projects', 'Mohamed Shazin Sadakath', 31);
INSERT INTO BOOK (TITLE, AUTHOR, PRICE) VALUES ('Cloud-Native Applications in Java', 'Ajay Mahajan, Munish Kumar Gupta, et al', 49);

