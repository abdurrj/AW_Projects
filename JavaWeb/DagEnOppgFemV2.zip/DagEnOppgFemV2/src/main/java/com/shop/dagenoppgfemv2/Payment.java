package com.shop.dagenoppgfemv2;

public interface Payment {

    void pay(int amount);
}
