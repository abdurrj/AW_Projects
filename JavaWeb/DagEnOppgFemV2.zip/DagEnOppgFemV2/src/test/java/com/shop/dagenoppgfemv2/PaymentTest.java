package com.shop.dagenoppgfemv2;

import static org.junit.jupiter.api.Assertions.*;

class PaymentTest {

}