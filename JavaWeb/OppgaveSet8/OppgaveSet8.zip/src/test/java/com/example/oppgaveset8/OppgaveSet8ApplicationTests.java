package com.example.oppgaveset8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OppgaveSet8ApplicationTests {

    @Test
    void contextLoads() {
    }

}
