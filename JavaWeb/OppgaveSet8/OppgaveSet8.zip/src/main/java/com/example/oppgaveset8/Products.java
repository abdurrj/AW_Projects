package com.example.oppgaveset8;

import java.util.List;

public class Products {
    List<String> products;

    public Products(){}

}
