package no.academy.lanterna;

public class Player {
    int xPos;
    int yPos;
    char playerChar =  '\u25CF';

    public Player(int xPos, int yPos) {
        this.xPos = xPos;
        this.yPos = yPos;
    }

}
