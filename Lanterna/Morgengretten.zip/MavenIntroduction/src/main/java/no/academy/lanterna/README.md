**MORGENGRETTEN**
-
_________________
**Senario:**
-

Det er tidlig på mandag morgen. Du ankommer jobb, er trøtt og skulle helst være i senga.
Du vet at kollegaene dine er ute etter å snakke med deg.
Prøv å unngå kollegaene dine, og kom deg til kaffekoppen! Drikk så mye kaffe du klarer før du blir huket tak i av en kollega!

___________________

**Kjente bugs:**
- 
- Trykk på knapper som ikke flytter spiller, gjør spilleren usynlig, fram til spiller flytter seg igjen.


**Planlagte oppdateringer:**
-
- Fikse bug
- Optimalisering av koden
- Legge til liv for spilleren

**Funksjonsønsker fra bruker:**
-
- Flere ting å gjøre i spillet (Flere kopper, andre ting å ta)

**Credits**
-
AW Academy Java for Accenture Høst 2021

Gruppe: Ambitious Interactions