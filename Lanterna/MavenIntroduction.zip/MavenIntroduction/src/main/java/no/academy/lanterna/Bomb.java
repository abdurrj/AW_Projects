package no.academy.lanterna;

public class Bomb {
    int xPos;
    int yPos;

    public Bomb(int xPos, int yPos) {
        this.xPos = xPos;
        this.yPos = yPos;
    }

    public int getX(){
        return xPos;
    }
    public int getY(){
        return yPos;
    }

}
