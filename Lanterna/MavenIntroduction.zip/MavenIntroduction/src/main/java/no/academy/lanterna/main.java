//Figuren bør ha 3 liv - som countes.
//Vi må ha en count for highScore som countes er spiste enhet + x antall poeng for flagg.
package no.academy.lanterna;

import com.googlecode.lanterna.*;
import com.googlecode.lanterna.graphics.TextGraphics;
import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.KeyType;
import com.googlecode.lanterna.screen.Screen;
import com.googlecode.lanterna.screen.TerminalScreen;
import com.googlecode.lanterna.terminal.DefaultTerminalFactory;
import com.googlecode.lanterna.terminal.Terminal;
import org.w3c.dom.Text;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class main {

    public static void main(String[] args) throws IOException, InterruptedException {

        //Lag terminal og skjul cursor
        DefaultTerminalFactory defaultTerminalFactory = new DefaultTerminalFactory();

        
        Terminal terminal = defaultTerminalFactory.createTerminal();


        Screen screen = new TerminalScreen(terminal);
        TextGraphics textGraphics = screen.newTextGraphics();
        screen.startScreen();

//        textGraphics.putString(2,1, "Hei", SGR.BLINK);
        //Thread.sleep(2000);

        KeyStroke startKeyStroke = null;
        boolean startReadingInput = true;

        while(startReadingInput == true) {
            do {
                textGraphics.putString(2, 1, "Velkommen! Press space to begin!", SGR.BLINK);
                screen.refresh();
                startKeyStroke = terminal.pollInput();
            } while (startKeyStroke == null);
            Character cStart = startKeyStroke.getCharacter();

            if (cStart == Character.valueOf(' ')) {
                startReadingInput = false;
                System.out.println("Starting game");
                terminal.clearScreen();

            }
        }
        terminal.resetColorAndSGR();

        terminal.flush();
        terminal.setCursorVisible(false);


        //Sett opp en player2 character og plasser den random et sted

        int x = 6;
        int y = 7;
        final char player2 = '\u2639';

        UserPlayer player = new UserPlayer(6, 7);



        terminal.setForegroundColor(TextColor.ANSI.GREEN_BRIGHT);
        terminal.setCursorPosition(player.xPos, player.yPos);
        terminal.putCharacter(player.playerChar);


        boolean continueReadingInput = true;



        List<Line> lineList = GameBoard.MapMaker(terminal);
        terminal.flush();

        List<Ghost> ghostList = makeGhosts(5, terminal, lineList);
        for (Ghost ghost : ghostList){
            terminal.setForegroundColor(TextColor.ANSI.RED_BRIGHT);
            terminal.setCursorPosition(ghost.xPos, ghost.yPos);
            terminal.putCharacter(ghost.ghostChar);
        }

        // Lag en liste med bomber, velg antall bomber som er ønsket
        List<Bomb> bombList = makeBomb(0 , terminal, lineList);

        // tegn inn bomber og linjer (egne funksjoner)
        drawBomb(bombList, terminal);
        drawLine(lineList, terminal);
        terminal.flush();

        int flagX = 78;
        int flagY = 22;


        while(continueReadingInput){

            int xPrevious = player.xPos;
            int yPrevious = player.yPos;
            KeyStroke keyStroke = null;
            do {
                Thread.sleep(5);
                keyStroke = terminal.pollInput();
            }while(keyStroke==null);
            KeyType type = keyStroke.getKeyType();
            Character c = keyStroke.getCharacter();
            switch(type){
                case ArrowDown -> {player.yPos++;}
                case ArrowUp ->   {player.yPos--;}
                case ArrowLeft -> {player.xPos--;}
                case ArrowRight-> {player.xPos++;}
            }
            if (x!=xPrevious || y!= yPrevious){
                for (Ghost g : ghostList){
                    terminal.setForegroundColor(TextColor.ANSI.RED_BRIGHT);
                    g.moveGhost(g, terminal, 1, player, lineList, bombList);
                }
            }

            terminal.setCursorPosition(player.xPos, player.yPos);
            if (isWall(lineList, terminal)){ // If wall
                terminal.setCursorPosition(xPrevious,yPrevious); // Ikke gå
                player.xPos = xPrevious; player.yPos = yPrevious;
            }
            else{
                terminal.setForegroundColor(TextColor.ANSI.GREEN_BRIGHT);
                terminal.putCharacter(player.playerChar);
                terminal.setCursorPosition(xPrevious, yPrevious);
                terminal.putCharacter(' ');
            }
            if (isBomb(bombList, terminal)){ // if Bomb
                continueReadingInput = false; // slutt å lese input
                System.out.println("Oh no! You hit a bomb!");
            }
            if (isGhost(ghostList, player)){
                continueReadingInput = false;
                System.out.println("You have been captured by a ghost");
            }
            if (c == Character.valueOf('q')){
                continueReadingInput = false;
                System.out.println("quit");
            }
            terminal.flush();
        }
    }


    // For alle linjer i linjelista, kjøre makeline funksjonen (ligger objektfilene)
    public static void drawLine(List<Line> lineList, Terminal terminal) throws IOException {
        for (Line line : lineList) {
            line.makeLine(line, terminal);
            }
        terminal.flush();
    }

    // for alle linjer i linjelista, sjekk om posisjonen til spiller er en veggposisjon
    public static boolean isWall(List<Line> lineList, Terminal terminal) throws IOException{
        for (Line line : lineList) {
            for (int i = 0; i < line.length; i++) {
                int tRow = terminal.getCursorPosition().getRow();
                int tCol = terminal.getCursorPosition().getColumn();
                int[] linePos = line.linePos[i];
                if (tRow == linePos[1] && tCol == linePos[0]) {
                    return true; // Hvis det er vegg, returner true (if wall sjekke oppe)
                }
            }
        }
        return false;
    }

    // For alle bomber i bombelista, sjekk om spillerposisjonen er på bombe
    public static boolean isBomb(List<Bomb> bombList, Terminal terminal) throws IOException{
        for (Bomb b : bombList){
            int tRow = terminal.getCursorPosition().getRow();
            int tCol = terminal.getCursorPosition().getColumn();
            if (tRow ==  b.getY() && tCol == b.getX()){
                return true;
            }
        }
        return false;
    }

    // Lage bomber og gi en liste med bomber
    public static List<Bomb> makeBomb(int amount, Terminal terminal, List<Line> lineList) throws IOException {
        List<Bomb> bombList = new ArrayList<>();
        for (int i = 0; i<amount; i++){
            Random r = new Random();
            int x = r.nextInt(80);
            int y = r.nextInt(24);
            terminal.setCursorPosition(x, y);
            while(isWall(lineList, terminal)) {
                x = r.nextInt(80);
                y = r.nextInt(24);
                terminal.setCursorPosition(x,y);
            }
            Bomb bomb = new Bomb(x, y);
            bombList.add(bomb);
        }
        return bombList;
    }

    public static List<Ghost> makeGhosts(int amount, Terminal terminal, List<Line> lineList) throws IOException {
        List<Ghost> ghostList = new ArrayList<>();
        for (int i = 0; i<amount;i++){
            Random r = new Random();
            int x = r.nextInt(80);
            int y = r.nextInt(24);
            terminal.setCursorPosition(x, y);
            while(isWall(lineList, terminal)) {
                x = r.nextInt(80);
                y = r.nextInt(24);
                terminal.setCursorPosition(x, y);
            }
            Ghost ghost = new Ghost(x, y);
            ghostList.add(ghost);
        }
        return ghostList;
    }

    public static void drawBomb(List<Bomb> bombList, Terminal terminal) throws IOException {
        for (Bomb b : bombList){
            terminal.setCursorPosition(b.getX(), b.getY());
            terminal.putCharacter('O');
        }
    }

    public static boolean isGhost(List<Ghost> ghostList, UserPlayer player){
        for (Ghost g : ghostList){
            if (g.xPos == player.xPos && g.yPos == player.yPos){
                System.out.println("OMNOMNOMNOM");
                return true;
            }
        }
        return false;
    }

//    public static boolean isGoal(UserPlayer player){
//        if player
//
//        return false;
//    }

}
