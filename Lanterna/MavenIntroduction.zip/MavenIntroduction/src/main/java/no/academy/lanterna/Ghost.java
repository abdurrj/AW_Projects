package no.academy.lanterna;

import com.googlecode.lanterna.terminal.Terminal;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import static no.academy.lanterna.main.isBomb;
import static no.academy.lanterna.main.isWall;

public class Ghost {
    int xPos;
    int yPos;
    char ghostChar = 'G';


    public Ghost(int xPos, int yPos) {
        this.xPos = xPos;
        this.yPos = yPos;
    }

    public static void moveGhost(Ghost ghost, Terminal terminal, int difficulty, UserPlayer player, List<Line> lineList, List<Bomb> bombList) throws IOException {
        for (int i = 0; i < difficulty; i++) {
            int xPrevGhost = ghost.xPos;
            int yPrevGhost = ghost.yPos;
            int moveDirection = ThreadLocalRandom.current().nextInt(0, 2);

            if (moveDirection == 0 || ghost.yPos == player.yPos) {
                if (player.xPos > ghost.xPos) {
                    terminal.setCursorPosition(ghost.xPos + 1, ghost.yPos);
                    if (!isWall(lineList, terminal) || isBomb(bombList, terminal)) {
                        ghost.xPos++;
                    }
                }
                if (player.xPos < ghost.xPos) {
                    terminal.setCursorPosition(ghost.xPos - 1, ghost.yPos);
                    if (!isWall(lineList, terminal)&& !isBomb(bombList, terminal)) {
                        ghost.xPos--;
                    }
                }
            } else {
                if (player.yPos > ghost.yPos) {
                    terminal.setCursorPosition(ghost.xPos, ghost.yPos + 1);
                    if (!isWall(lineList, terminal)&& !isBomb(bombList, terminal)) {
                        ghost.yPos++;
                    }
                }
                if (player.yPos < ghost.yPos) {
                    terminal.setCursorPosition(ghost.xPos, ghost.yPos - 1);
                    if (!isWall(lineList, terminal) && !isBomb(bombList, terminal)) {
                        ghost.yPos--;
                    }
                }
            }
            terminal.setCursorPosition(ghost.xPos, ghost.yPos);
            terminal.putCharacter(ghost.ghostChar);
            if (xPrevGhost != ghost.xPos || yPrevGhost != ghost.yPos) {
                terminal.setCursorPosition(xPrevGhost, yPrevGhost);
                terminal.putCharacter(' ');
            }
        }
    }

}
