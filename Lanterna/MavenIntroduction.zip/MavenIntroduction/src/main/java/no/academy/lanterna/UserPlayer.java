package no.academy.lanterna;

public class UserPlayer {
    int xPos;
    int yPos;
    char playerChar =  '\u2639';

    public UserPlayer(int xPos, int yPos) {
        this.xPos = xPos;
        this.yPos = yPos;
    }
}
