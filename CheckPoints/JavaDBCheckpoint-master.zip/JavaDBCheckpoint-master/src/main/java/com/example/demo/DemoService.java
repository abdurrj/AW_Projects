package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DemoService {

    public List<Movie> getDataWithJDBC(int price) {

        // todo use JDBC to return a list of movies with a price over 42 and ordered by price descending
        List<Movie> movies = new ArrayList<>();

        return movies;
    }

    public List<Movie> getDataWithJPA(int price) {

        // todo use JPA to return a list of movies with a price over 42 and ordered by price descending
        List<Movie> movies = new ArrayList<>();

        return movies;
    }
}
