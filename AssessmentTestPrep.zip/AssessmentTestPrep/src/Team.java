public class Team {

    private String name;
    private int victories;

    public Team(String name, int victories) {

    }

    public String info() {
        return "";
    }

    public String getName() {
        return name;
    }

    public int getVictories() {
        return victories;
    }

}
