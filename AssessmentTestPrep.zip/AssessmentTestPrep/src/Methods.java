public class Methods {


    public static String mostWins(Team teamOne, Team teamTwo) {
        return "Who won most?";
    }

    public static int calculatePayoutOrProfit(int wagetAmount, int odds, boolean calculateNetProfit) {
        return 0;
    }

    public static int numberOfMatchesPrTeam(int numberOfTeamsInLeague) {
        return 0;
    }

    public static int numberOfMatchesTotalInASeason(int numberOfTeamsInLeague) {
        return 0;
    }

    public static int calculatePoints(int wins, int draws, int losses) {
        return 0;
    }

    public static int calculatePlayersLeft(int players, int amountOfRedCards) {
        return 0;
    }
}
