package com.example.JDBC;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Repository
public class BookRepository {

    @Autowired
    private DataSource dataSource;


    // Helper method to create a Book object instantiated with data from the ResultSet
    private Book rsBook(ResultSet rs) throws SQLException {
        return new Book(rs.getInt("id"),
                rs.getString("title"),
                rs.getString("author"),
                rs.getInt("price"));
    }


}
